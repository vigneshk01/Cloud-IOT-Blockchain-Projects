#!/bin/bash
(
yum update -y
amazon-linux-extras install -y python3.8
python3 -m pip install --upgrade pip
echo "pre-install-end"
) |& tee -a /var/log/user-data.log
