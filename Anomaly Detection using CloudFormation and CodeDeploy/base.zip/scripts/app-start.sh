#!/bin/bash
(
echo "app-start"

SOURCE="raw_data.py"
SERVICE_PATH="/HealthcareService"
SOURCE_PATH="$SERVICE_PATH/$SOURCE"

echo $SOURCE_PATH
python3 $SOURCE_PATH > /dev/null 2> tee -a /var/log/user-data.log < /dev/null &
) |& tee -a /var/log/user-data.log
