#!/bin/bash
(

SOURCE_FILE="raw_data.py"
REQ_FILE="requirements.txt"
SERVICE="service"
ARTIFACT="files.zip"

SUFFIX="deployment-archive"
HOME_PATH="/opt/codedeploy-agent/deployment-root"

LOCAL_PREFIX="$HOME_PATH/$DEPLOYMENT_GROUP_ID/$DEPLOYMENT_ID/$SUFFIX"

ARTIFACT_PATH="$LOCAL_PREFIX/$ARTIFACT"
CODE_PATH="$LOCAL_PREFIX/$SERVICE"

SOURCE_PATH="$CODE_PATH/$SOURCE_FILE"
REQ_PATH="$CODE_PATH/$REQ_FILE"

SERVICE_PATH="/HealthcareService"
FRESH_REQ_PATH="$SERVICE_PATH/$REQ_FILE"

if [ ! -d "/HealthcareService" ]
then
	mkdir /HealthcareService
fi

pwd
unzip -o $ARTIFACT_PATH -d $LOCAL_PREFIX

cp -r $SOURCE_PATH $SERVICE_PATH
cp -r $REQ_PATH $SERVICE_PATH

python3 -m pip install -r $FRESH_REQ_PATH
echo "post-install-end"
) |& tee -a /var/log/user-data.log 
